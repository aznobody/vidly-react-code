import React, { Component } from "react";
import http from './services/httpService';
import {ToastContainer,toast} from 'react-toastify';
import * as Sentry from '@sentry/browser';
import 'react-toastify/dist/ReactToastify.css'  
import "./App.css";
const api="https://jsonplaceholder.typicode.com/posts";

class App extends Component {
  state = {
    posts: []
  };

async componentDidMount() {
  const {data:posts}= await http.get(api);;
  this.setState({posts})
}
  handleAdd = async () => {
    const {data:post}=await http.post(api,{title:'a', body:'b'});
    const posts=[post,...this.state.posts];
    this.setState({posts})
  };

  handleUpdate = async (post) => {
    post.title="UPDATED";
    await http.put(api+"/"+post.id,post);
    const posts= [...this.state.posts];
    const index= posts.indexOf(post);
    posts[index]={...post};
    this.setState({posts});
  };

  handleDelete = async (post) => {
    //optmistic update
    const originalPosts= this.state.posts;

    const posts=[...this.state.posts];
    const up= posts.filter(p=>p.id!=post.id);
    this.setState({posts:up});
    try{
      await http.delete(api+'/'+post.id);
    }catch(ex){
      //handle specific errors here
      //generic error(unexpected) are handled in httpService by axios interceptot
      if(ex.response && ex.response.status==404)
      toast.error('This post has been deleted already!');
      this.setState({posts:originalPosts});
    }
    
  };

  render() {
    return (
      <React.Fragment>
        <ToastContainer/>
        <button className="btn btn-primary" onClick={this.handleAdd}>
          Add
        </button>
        <table className="table">
          <thead>
            <tr>
              <th>Title</th>
              <th>Update</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {this.state.posts.map(post => (
              <tr key={post.id}>
                <td>{post.title}</td>
                <td>
                  <button
                    className="btn btn-info btn-sm"
                    onClick={() => this.handleUpdate(post)}
                  >
                    Update
                  </button>
                </td>
                <td>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => this.handleDelete(post)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </React.Fragment>
    );
  }
}

export default App;
